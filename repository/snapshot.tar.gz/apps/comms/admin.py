# ==========================================================
#
# █▀█ █ █▄█ ▄▀█ █▀  █▀▀ █▀▀
# ▀▀█ █ ░█░ █▀█ ▄█  █▄▄ █▄▄
#
# Project     : CC Journal
# Developed by: Qiyas CC
# Copyright © 2026 Qiyas CC
# All Rights Reserved.
# ==========================================================

from django.contrib import admin
from unfold.admin import ModelAdmin
from rangefilter.filters import DateTimeRangeFilterBuilder

from .models import EmailLog, EmailTemplate, Notification


@admin.register(EmailTemplate)
class EmailTemplateAdmin(ModelAdmin):
    list_display = ("key", "locale", "journal", "enabled")
    list_filter = ("key", "locale", "enabled", "journal")
    search_fields = ("subject", "body")


@admin.register(Notification)
class NotificationAdmin(ModelAdmin):
    list_display = ("title", "recipient", "type", "is_read", "created_at")
    list_filter = ("type", "is_read")
    search_fields = ("title", "recipient__email")
    readonly_fields = ("created_at",)


@admin.register(EmailLog)
class EmailLogAdmin(ModelAdmin):
    list_display = ("created_at", "subject", "to_emails", "template_key", "status")
    list_filter = ("status", "template_key", "locale",
                   ("created_at", DateTimeRangeFilterBuilder(title="Sent")))
    search_fields = ("subject", "to_emails", "body")
    date_hierarchy = "created_at"
    readonly_fields = ("journal", "template_key", "locale", "from_email", "to_emails",
                       "subject", "body", "status", "error", "content_type", "object_id",
                       "created_at")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
