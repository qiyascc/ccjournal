# ==========================================================
#
# █▀█ █ █▄█ ▄▀█ █▀  █▀▀ █▀▀
# ▀▀█ █ ░█░ █▀█ ▄█  █▄▄ █▄▄
#
# Project     : CC Journal
# Developed by: Qiyas CC
# Copyright © 2026 Qiyas CC
# All Rights Reserved.
# ==========================================================

"""Kuyruğa uygun e-posta işleri (serialize-edilebilir argümanlar)."""
from __future__ import annotations


def send_author_action_email(submission_id: int, title: str, kind: str,
                             work_url: str) -> dict:
    """Yazara aşama bildirimi e-postası (kuyruk veya inline)."""
    from apps.submissions.models import Submission
    from .services import MailService

    sub = (Submission.objects.select_related("journal", "submitter")
           .filter(id=submission_id).first())
    if not sub or not sub.submitter or not sub.submitter.email:
        return {"sent": False, "reason": "no recipient"}
    MailService.send("author_action", journal=sub.journal, related=sub,
                     locale=sub.locale, to=[sub.submitter.email],
                     context={"title": title, "kind": kind, "work_url": work_url,
                              "journal": str(sub.journal)})
    return {"sent": True, "submission": submission_id}


def notify_readers_new_issue(issue_id: int) -> dict:
    """Yeni sayı e-postası — opt-in (notify_new_issue) tüm aktif kullanıcılara.

    OJS "Notify readers" karşılığı; sayı yayımlanınca IssueService kuyruğa atar.
    Kişi başına tek tek gönderilir (BCC listesi sızıntısı olmaz); alıcının tercih
    dili derginin desteklediği dillerdeyse o dil kullanılır.
    """
    from apps.accounts.models import User
    from apps.journals.models import Issue
    from .services import MailService
    from .utils import absolute_url

    issue = Issue.objects.select_related("journal").filter(id=issue_id).first()
    if not issue or not issue.is_published:
        return {"sent": 0, "reason": "issue missing or unpublished"}
    journal = issue.journal
    supported = journal.supported_locales or [journal.primary_locale]
    ctx_base = {
        "issue": str(issue), "journal": str(journal),
        "issue_url": absolute_url(f"/issue/{issue.pk}/"),
        "profile_url": absolute_url("/accounts/profile/"),
    }
    sent = 0
    qs = (User.objects.filter(is_active=True, notify_new_issue=True)
          .exclude(email=""))
    for u in qs.iterator():
        locale = u.preferred_locale if u.preferred_locale in supported \
            else journal.primary_locale
        ok = MailService.send("issue_published", journal=journal, locale=locale,
                              to=[u.email], related=issue, context=dict(ctx_base))
        sent += int(bool(ok))
    return {"sent": sent, "issue": issue_id}
