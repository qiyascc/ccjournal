# ==========================================================
#
# █▀█ █ █▄█ ▄▀█ █▀  █▀▀ █▀▀
# ▀▀█ █ ░█░ █▀█ ▄█  █▄▄ █▄▄
#
# Project     : CC Journal
# Developed by: Qiyas CC
# Copyright © 2026 Qiyas CC
# All Rights Reserved.
# ==========================================================

"""
Sinyal alıcıları: iş-akışı olaylarını bildirim + e-postaya bağlar.
AppConfig.ready() içinde import edilerek aktive olur.
"""
from __future__ import annotations

from django.dispatch import receiver

from apps.accounts.models import User
from apps.accounts.roles import EDITORIAL_ROLE_NAMES
from .services import (
    MailService, NotifyService,
    decision_recorded, publication_published, review_assigned, submission_created,
)


def _journal_locale(journal, user=None) -> str:
    """
    E-posta dili: VARSAYILAN derginin primary_locale'i. Alıcının tercih ettiği dil
    dergi tarafından destekleniyorsa o kullanılır (aksi halde primary). MailService
    ayrıca şablon yoksa 'en'e düşer.
    """
    primary = journal.primary_locale
    supported = journal.supported_locales or [primary]
    pref = getattr(user, "preferred_locale", None) if user else None
    return pref if pref in supported else primary


def _author_email_and_locale(submission):
    user = submission.submitter
    emails = [user.email] if user and user.email else []
    return emails, _journal_locale(submission.journal, user)


@receiver(submission_created)
def on_submission_created(sender, submission, **kwargs):
    journal = submission.journal
    pub = submission.current_publication
    title = pub.tr_value("title") if pub else f"#{submission.id}"
    to, locale = _author_email_and_locale(submission)

    if submission.submitter:
        NotifyService.create(submission.submitter, "submission_ack",
                             "Submission received", body=title, journal=journal,
                             url=f"/submit/{submission.id}/done/")
    MailService.send("submission_ack", journal=journal, locale=locale, to=to, related=submission,
                     context={"title": title, "journal": str(journal)})

    editors = User.objects.filter(
        groups__name__in=EDITORIAL_ROLE_NAMES, is_active=True).distinct()
    for u in editors:
        NotifyService.create(u, "new_submission", "New submission",
                             body=title, journal=journal,
                             url=f"/admin/submissions/submission/{submission.id}/change/")
        if u.email:
            MailService.send("editor_new_submission", journal=journal, related=submission,
                             locale=_journal_locale(journal, u), to=[u.email],
                             context={"title": title, "journal": str(journal)})


@receiver(review_assigned)
def on_review_assigned(sender, assignment, **kwargs):
    from .utils import absolute_url
    reviewer = assignment.reviewer
    submission = assignment.review_round.submission
    review_url = f"/review/{assignment.access_token}/"
    NotifyService.create(reviewer, "review_request", "Review request",
                         journal=submission.journal,
                         url=review_url)
    if reviewer.email:
        MailService.send("review_request", journal=submission.journal, related=submission,
                         locale=_journal_locale(submission.journal, reviewer), to=[reviewer.email],
                         context={"due": assignment.date_due, "journal": str(submission.journal),
                                  "review_url": absolute_url(review_url)})


@receiver(decision_recorded)
def on_decision_recorded(sender, decision, notify_author=True, **kwargs):
    from apps.review.models import EditorialDecision
    submission = decision.submission
    to, locale = _author_email_and_locale(submission)
    key_map = {
        EditorialDecision.Decision.ACCEPT: "decision_accept",
        EditorialDecision.Decision.DECLINE: "decision_decline",
        EditorialDecision.Decision.INITIAL_DECLINE: "decision_decline",
        EditorialDecision.Decision.PENDING_REVISIONS: "decision_revisions",
    }
    key = key_map.get(decision.decision)
    if not key or not submission.submitter:
        return
    from .utils import absolute_url
    NotifyService.create(submission.submitter, key, decision.get_decision_display(),
                         body=decision.note, journal=submission.journal)
    if not notify_author:
        return
    work_url = absolute_url(f"/work/{submission.author_token}/")
    MailService.send(key, journal=submission.journal, locale=locale, to=to, related=submission,
                     context={"decision": decision.get_decision_display(), "note": decision.note,
                              "work_url": work_url})


@receiver(publication_published)
def on_publication_published(sender, publication, **kwargs):
    submission = publication.submission
    if not submission.submitter:
        return
    title = publication.tr_value("title")
    to, locale = _author_email_and_locale(submission)
    NotifyService.create(submission.submitter, "published", "Your article is published",
                         body=title, journal=submission.journal)
    MailService.send("publication_published", journal=submission.journal, locale=locale, related=submission,
                     to=to, context={"title": title, "journal": str(submission.journal)})
