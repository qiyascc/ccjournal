# ==========================================================
#
# █▀█ █ █▄█ ▄▀█ █▀  █▀▀ █▀▀
# ▀▀█ █ ░█░ █▀█ ▄█  █▄▄ █▄▄
#
# Project     : CC Journal
# Developed by: Qiyas CC
# Copyright © 2026 Qiyas CC
# All Rights Reserved.
# ==========================================================

from django import forms
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.shortcuts import redirect, render

from .models import User


class ThrottledLoginView(LoginView):
    """5 başarısız denemeden sonra (ip/e-posta başına) 15 dk kilitleyen giriş."""

    def post(self, request, *args, **kwargs):
        from . import throttle
        username = request.POST.get("username", "")
        if throttle.is_locked(request, username):
            return render(request, "registration/login.html",
                          {"locked_out": True, "next": request.POST.get("next", "")},
                          status=429)
        return super().post(request, *args, **kwargs)


class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, min_length=8)

    class Meta:
        model = User
        fields = ("email", "given_name", "family_name", "affiliation", "orcid",
                  "notify_new_issue")

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user


def register(request):
    from constance import config
    if not config.REGISTRATION_OPEN:
        messages.error(request, "Registration is currently closed.")
        return redirect("login")
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("dashboard")
    else:
        form = RegisterForm()
    return render(request, "registration/register.html", {"form": form})


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ("given_name", "family_name", "affiliation", "affiliation_ror",
                  "orcid", "country", "biography", "preferred_locale",
                  "notify_new_issue")
        widgets = {"biography": forms.Textarea(attrs={"rows": 4})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        try:
            from apps.core.locales import locale_label
            from apps.journals.models import Journal
            j = Journal.current()
            supported = (j.supported_locales or [j.primary_locale]) if j else ["en"]
            self.fields["preferred_locale"] = forms.ChoiceField(
                choices=[(c, locale_label(c)) for c in supported],
                label="Preferred language", required=False)
        except Exception:
            pass


@login_required
def profile(request):
    if request.method == "POST":
        form = ProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated.")
            return redirect("profile")
    else:
        form = ProfileForm(instance=request.user)
    return render(request, "registration/profile.html", {"form": form})


class InviteRegisterForm(forms.Form):
    given_name = forms.CharField(max_length=150, label="Given name")
    family_name = forms.CharField(max_length=150, required=False, label="Family name")
    password = forms.CharField(widget=forms.PasswordInput, min_length=8, label="Password")


def invitation_accept(request, token):
    """Rol davetini kabul et: hesap kur (yoksa) veya mevcut hesaba rolü ekle."""
    from django.shortcuts import get_object_or_404
    from django.utils import timezone

    from .models import JournalMembership, User, UserInvitation

    inv = get_object_or_404(UserInvitation, token=token)
    ctx = {"inv": inv, "role_label": inv.get_role_display()}
    if not inv.is_valid:
        return render(request, "registration/invite.html",
                      {**ctx, "state": "invalid"}, status=410)

    def _accept(user):
        JournalMembership.objects.get_or_create(
            user=user, journal=inv.journal, role=inv.role)
        inv.accepted_at = timezone.now()
        inv.accepted_by = user
        inv.save(update_fields=["accepted_at", "accepted_by"])
        messages.success(request,
                         f"Welcome — the {inv.get_role_display()} role has been added.")
        return redirect("dashboard")

    existing = User.objects.filter(email__iexact=inv.email).first()
    if existing:
        if request.user.is_authenticated and request.user.pk == existing.pk:
            if request.method == "POST":
                return _accept(existing)
            return render(request, "registration/invite.html",
                          {**ctx, "state": "confirm"})
        return render(request, "registration/invite.html",
                      {**ctx, "state": "login_required"})

    form = InviteRegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = User.objects.create_user(
            email=inv.email, password=form.cleaned_data["password"],
            given_name=form.cleaned_data["given_name"],
            family_name=form.cleaned_data["family_name"])
        login(request, user)
        return _accept(user)
    return render(request, "registration/invite.html",
                  {**ctx, "state": "register", "form": form})
