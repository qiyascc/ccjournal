# ==========================================================
#
# █▀█ █ █▄█ ▄▀█ █▀  █▀▀ █▀▀
# ▀▀█ █ ░█░ █▀█ ▄█  █▄▄ █▄▄
#
# Project     : CC Journal
# Developed by: Qiyas CC
# Copyright © 2026 Qiyas CC
# All Rights Reserved.
# ==========================================================

"""
Vitrin (reader-facing) view'ları — tek dergi.

İçerik dili (content locale) yönetimi: ?lang=xx ile değişir, oturumda saklanır,
yoksa derginin primary_locale'ine düşer. Bu, admin arayüz dilinden (İngilizce)
bağımsızdır.
"""
from __future__ import annotations

from django.http import FileResponse, Http404
from django.views.decorators.clickjacking import xframe_options_sameorigin
from django.urls import reverse
from django.shortcuts import get_object_or_404, redirect, render

from apps.journals.models import Issue, Journal, Section
from apps.publications.models import Galley, Publication, PublicationStatus
from apps.submissions.models import Submission, SubmissionStatus
from apps.metadata.oai import oai_identifier


def _journal_or_404() -> Journal:
    j = Journal.current()
    if not j:
        raise Http404("No journal configured.")
    return j


def _content_locale(request, journal) -> str:
    supported = journal.supported_locales or [journal.primary_locale]
    from django.conf import settings as dj
    if getattr(dj, "LANGUAGE_URL_TYPE", "query") == "slug":
        from django.utils import translation
        active = translation.get_language() or ""
        if active in supported:
            return active
        base = active.split("-")[0]
        return base if base in supported else journal.primary_locale
    lang = request.GET.get("lang")
    if lang and lang in supported:
        request.session["content_locale"] = lang
        return lang
    return request.session.get("content_locale") or journal.primary_locale


def _base_ctx(request, journal):
    from apps.core.locales import locale_label
    cloc = _content_locale(request, journal)
    supported = journal.supported_locales or [journal.primary_locale]
    return {
        "journal": journal,
        "cloc": cloc,
        "languages": [(c, locale_label(c)) for c in supported],
        "language_links": _language_links(request, supported),
        "submit_url": _submit_url(request),
    }


def _language_links(request, supported):
    """Dil switcher hedefleri — query: ?lang=xx · slug: /xx/<yol>."""
    from django.conf import settings as dj
    from apps.core.locales import locale_label
    out = []
    if getattr(dj, "LANGUAGE_URL_TYPE", "query") == "slug":
        from apps.web.language import switch_lang_path
        for c in supported:
            out.append((c, locale_label(c), switch_lang_path(request.path, c)))
    else:
        for c in supported:
            out.append((c, locale_label(c), f"?lang={c}"))
    return out


def _submit_url(request):
    """Form Engine aktifse gönderim, form.<domain>/submission/ adresine gider."""
    try:
        from apps.configuration.services import Config
        sub = (Config.get("forms", "subdomain", "form") or "").strip().lower()
        if not sub:
            return "/submit/"
        host = request.get_host()
        bare = host.split(":")[0]
        if bare.split(".")[0] == sub:
            return "/submission/"
        return f"{request.scheme}://{sub}.{host}/submission/"
    except Exception:
        return "/submit/"


def _published_pubs():
    return Publication.objects.filter(
        status=PublicationStatus.PUBLISHED).select_related("submission", "section", "issue", "doi")


def home(request):
    journal = _journal_or_404()
    ctx = _base_ctx(request, journal)
    current = journal.issues.filter(is_published=True, is_current=True).first() \
        or journal.issues.filter(is_published=True).first()
    ctx["current_issue"] = current
    ctx["current_pubs"] = (current.publications.filter(status=PublicationStatus.PUBLISHED)
                           .select_related("section").order_by("section__seq", "seq")) if current else []
    from constance import config
    ctx["recent"] = _published_pubs().order_by("-date_published")[:config.ITEMS_PER_PAGE]
    return render(request, "web/home.html", ctx)


def issue_archive(request):
    journal = _journal_or_404()
    ctx = _base_ctx(request, journal)
    ctx["issues"] = journal.issues.filter(is_published=True)
    return render(request, "web/archive.html", ctx)


def issue_detail(request, pk):
    journal = _journal_or_404()
    issue = get_object_or_404(Issue, pk=pk, journal=journal, is_published=True)
    ctx = _base_ctx(request, journal)
    ctx["issue"] = issue
    pubs = (issue.publications.filter(status=PublicationStatus.PUBLISHED)
            .select_related("section").prefetch_related("authors").order_by("section__seq", "seq"))
    groups: dict = {}
    for p in pubs:
        groups.setdefault(p.section_id, {"section": p.section, "items": []})["items"].append(p)
    ctx["toc"] = list(groups.values())
    return render(request, "web/issue.html", ctx)


def article(request, pk):
    journal = _journal_or_404()
    submission = get_object_or_404(
        Submission, pk=pk, journal=journal, status=SubmissionStatus.PUBLISHED)
    ctx = _base_ctx(request, journal)

    versions = (submission.publications.filter(status=PublicationStatus.PUBLISHED)
                .order_by("-version_major", "-version_minor"))
    pub = submission.current_publication
    vid = request.GET.get("version")
    if vid:
        pub = get_object_or_404(versions, pk=vid)
    if not pub or pub.status != PublicationStatus.PUBLISHED:
        raise Http404("Not published.")

    ctx.update({
        "submission": submission,
        "pub": pub,
        "versions": versions,
        "authors": pub.authors.all().order_by("seq"),
        "galleys": pub.galleys.filter(is_approved=True).order_by("seq"),
        "oai_id": oai_identifier(journal.path, submission.id),
        "fulltext": (pub.tr(ctx["cloc"]).body
                     if pub.tr(ctx["cloc"]) and getattr(pub.tr(ctx["cloc"]), "body", "")
                     else ""),
    })
    from apps.stats.models import Metric
    from apps.stats.services import StatsService
    StatsService.record(request, submission, Metric.ABSTRACT_VIEW)
    from constance import config as _cfg
    ctx["stats"] = StatsService.totals(submission) if _cfg.SHOW_ABSTRACT_VIEWS else None
    from apps.plugins.hooks import hooks
    ctx["plugin_html"] = hooks.apply_filters(
        "templates.article_extra", "", publication=pub, request=request)
    ctx["jsonld"] = _article_jsonld(request, submission, pub, ctx)
    return render(request, "web/article.html", ctx)


def _article_jsonld(request, submission, pub, ctx):
    """schema.org ScholarlyArticle JSON-LD (Google zengin sonuçlar)."""
    import json
    t = pub.tr(ctx["cloc"])
    authors = [{"@type": "Person",
                "name": f"{a.given_name} {a.family_name}".strip(),
                **({"affiliation": a.affiliation} if a.affiliation else {}),
                **({"sameAs": f"https://orcid.org/{a.orcid}"} if a.orcid else {})}
               for a in pub.authors.all()]
    data = {
        "@context": "https://schema.org", "@type": "ScholarlyArticle",
        "headline": (t.title if t else ""),
        "abstract": (t.abstract if t else "") or "",
        "author": authors,
        "url": request.build_absolute_uri(request.path),
        "inLanguage": ctx["cloc"],
    }
    if pub.date_published:
        data["datePublished"] = pub.date_published.isoformat()
    if getattr(pub, "doi_id", None):
        data["sameAs"] = pub.doi.url
    j = ctx.get("journal")
    if j:
        jt = None
        try:
            from apps.journals.models import JournalTranslation
            row = JournalTranslation.objects.filter(journal=j).first()
            jt = row.title if row else None
        except Exception:
            pass
        data["isPartOf"] = {"@type": "Periodical", "name": jt or "Journal",
                            **({"issn": j.issn_online} if j.issn_online else {})}
    return json.dumps(data, ensure_ascii=False)


def section_browse(request, pk):
    journal = _journal_or_404()
    section = get_object_or_404(Section, pk=pk, journal=journal)
    ctx = _base_ctx(request, journal)
    ctx["section"] = section
    ctx["pubs"] = _published_pubs().filter(section=section).order_by("-date_published")
    return render(request, "web/section.html", ctx)


def search(request):
    journal = _journal_or_404()
    ctx = _base_ctx(request, journal)
    q = (request.GET.get("q") or "").strip()
    ctx["q"] = q
    if q:
        from apps.search.services import SearchIndex
        ids = SearchIndex.search(q)
        pubs = {p.submission_id: p for p in _published_pubs().filter(submission_id__in=ids)}
        ctx["results"] = [pubs[i] for i in ids if i in pubs]
    else:
        ctx["results"] = None
    return render(request, "web/search.html", ctx)


@xframe_options_sameorigin
def galley(request, pk, galley_id):
    journal = _journal_or_404()
    submission = get_object_or_404(
        Submission, pk=pk, journal=journal, status=SubmissionStatus.PUBLISHED)
    g = get_object_or_404(Galley, pk=galley_id, publication__submission=submission, is_approved=True)
    from apps.subscriptions.services import SubscriptionService
    issue = getattr(g.publication, "issue", None)
    if not SubscriptionService.has_access(request.user, issue):
        ctx = _base_ctx(request, journal)
        ctx["submission"] = submission
        return render(request, "web/subscription_required.html", ctx, status=403)
    from apps.stats.models import Metric
    from apps.stats.services import StatsService
    StatsService.record(request, submission, Metric.GALLEY_VIEW, galley=g)
    if g.remote_url:
        return redirect(g.remote_url)
    if not g.file or not g.file.file:
        raise Http404("No file.")
    resp = FileResponse(g.file.file.open("rb"))
    if g.file.mimetype:
        resp["Content-Type"] = g.file.mimetype
    is_pdf = (g.file.mimetype or "").endswith("pdf") or \
             (g.file.original_filename or "").lower().endswith(".pdf")
    force_dl = request.GET.get("download") == "1"
    disposition = "attachment" if (force_dl or not is_pdf) else "inline"
    import unicodedata
    from urllib.parse import quote
    raw_name = g.file.original_filename or "galley.pdf"
    ascii_name = (unicodedata.normalize("NFKD", raw_name)
                  .encode("ascii", "ignore").decode("ascii")) or "galley.pdf"
    resp["Content-Disposition"] = (
        f"{disposition}; filename=\"{ascii_name}\"; "
        f"filename*=UTF-8''{quote(raw_name)}")
    resp["X-Frame-Options"] = "SAMEORIGIN"
    return resp


def setup(request):
    """Dergi yapılandırılmamışsa superuser ilk kurulumu burada yapar."""
    from django.contrib.auth.decorators import login_required as _ld  # noqa
    if Journal.current():
        return redirect("web:home")
    if not (request.user.is_authenticated and request.user.is_superuser):
        from django.contrib.auth.views import redirect_to_login
        return redirect_to_login(request.get_full_path())

    from .forms import SetupForm
    from apps.journals.models import JournalTranslation
    from apps.submissions.models import Genre
    if request.method == "POST":
        form = SetupForm(request.POST, request.FILES)
        if form.is_valid():
            cd = form.cleaned_data
            journal = Journal.objects.create(
                path="journal", primary_locale=cd["primary_locale"],
                supported_locales=cd["supported_locales"],
                publisher=cd["publisher"], contact_email=cd["contact_email"],
                issn_online=cd["issn_online"], logo=cd.get("logo") or "",
                enabled=True,
            )
            JournalTranslation.objects.create(
                journal=journal, locale=cd["primary_locale"], title=cd["title"])
            from apps.journals.models import Section, SectionTranslation
            sec = Section.objects.create(journal=journal, primary_locale=cd["primary_locale"])
            SectionTranslation.objects.create(
                section=sec, locale=cd["primary_locale"], title="Articles")
            for key, name in [("article", "Article Text"), ("supp", "Supplementary")]:
                Genre.objects.get_or_create(
                    journal=journal, key=key,
                    defaults={"name": name, "is_supplementary": key == "supp"})
            return redirect("web:home")
    else:
        form = SetupForm()
    return render(request, "web/setup.html", {"form": form})


def page(request, slug):
    """Statik sayfa — içerik, içerik-diline (cloc) göre, geri-düşüşlü."""
    from apps.pages.models import StaticPage
    journal = _journal_or_404()
    ctx = _base_ctx(request, journal)
    pg = get_object_or_404(StaticPage, journal=journal, slug=slug, is_published=True)
    t = pg.tr(ctx["cloc"])
    if not t:
        raise Http404
    ctx.update({
        "page": pg, "ptitle": t.title, "pcontent": t.content,
        "meta_title": t.meta_title or t.title,
        "meta_description": t.meta_description,
        "canonical_url": pg.canonical_url or request.build_absolute_uri(request.path),
        "robots_noindex": pg.robots_noindex,
        "og_image": (pg.og_image.url if pg.og_image else ""),
    })
    return render(request, "web/page.html", ctx)


def announcements(request):
    """Aktif duyurular listesi (yayında + süresi geçmemiş)."""
    from django.utils import timezone
    from django.db.models import Q
    from apps.announcements.models import Announcement
    journal = _journal_or_404()
    ctx = _base_ctx(request, journal)
    today = timezone.localdate()
    qs = (Announcement.objects.filter(journal=journal, is_published=True)
          .filter(Q(date_expire__isnull=True) | Q(date_expire__gte=today))
          .prefetch_related("translations").order_by("-date_posted"))
    items = []
    for a in qs:
        t = a.tr(ctx["cloc"])
        if t:
            items.append({"obj": a, "title": t.title,
                          "short": t.short_description, "date": a.date_posted})
    ctx["announcements"] = items
    return render(request, "web/announcements.html", ctx)


def announcement_detail(request, pk):
    from apps.announcements.models import Announcement
    journal = _journal_or_404()
    ctx = _base_ctx(request, journal)
    a = get_object_or_404(Announcement, pk=pk, journal=journal, is_published=True)
    if not a.is_active:
        raise Http404
    t = a.tr(ctx["cloc"])
    if not t:
        raise Http404
    ctx.update({"ann": a, "atitle": t.title, "abody": t.body,
                "ashort": t.short_description})
    return render(request, "web/announcement_detail.html", ctx)


def categories(request):
    """Üst düzey kategoriler."""
    from apps.journals.models import Category
    journal = _journal_or_404()
    ctx = _base_ctx(request, journal)
    tops = (Category.objects.filter(journal=journal, parent__isnull=True)
            .prefetch_related("translations", "children__translations").order_by("seq"))
    ctx["categories"] = [{"obj": c, "t": c.tr(ctx["cloc"]),
                          "children": [{"obj": k, "t": k.tr(ctx["cloc"])}
                                       for k in c.children.all()]} for c in tops]
    return render(request, "web/categories.html", ctx)


def category_browse(request, slug):
    """Kategori detayı: alt kategoriler + bu kategori (ve altları) altındaki yayınlar."""
    from apps.journals.models import Category
    journal = _journal_or_404()
    ctx = _base_ctx(request, journal)
    cat = get_object_or_404(Category, journal=journal, slug=slug)
    ids = cat.descendant_ids()
    pubs = (_published_pubs().filter(submission__categories__in=ids).distinct()
            .select_related("section").prefetch_related("authors")
            .order_by("-date_published"))
    ctx.update({
        "category": cat, "ctitle": (cat.tr(ctx["cloc"]).title if cat.tr(ctx["cloc"]) else cat.slug),
        "cdesc": (cat.tr(ctx["cloc"]).description if cat.tr(ctx["cloc"]) else ""),
        "subcats": [{"obj": k, "t": k.tr(ctx["cloc"])} for k in cat.children.all().order_by("seq")],
        "pubs": pubs,
    })
    return render(request, "web/category.html", ctx)


def robots_txt(request):
    from django.http import HttpResponse
    lines = ["User-agent: *", "Disallow: /admin/", "Disallow: /manage/",
             "Disallow: /rosetta/", "Disallow: /hijack/", "Disallow: /api/",
             "Allow: /",
             f"Sitemap: {request.scheme}://{request.get_host()}/sitemap.xml"]
    return HttpResponse("\n".join(lines), content_type="text/plain")


def galley_view(request, pk, galley_id):
    """HTML/PDF galley'i okuyucu kabuğu içinde gömülü gösterir (tam-metin görünümü)."""
    journal = _journal_or_404()
    submission = get_object_or_404(
        Submission, pk=pk, journal=journal, status=SubmissionStatus.PUBLISHED)
    g = get_object_or_404(Galley, pk=galley_id,
                          publication__submission=submission, is_approved=True)
    from apps.subscriptions.services import SubscriptionService
    issue = getattr(g.publication, "issue", None)
    if not SubscriptionService.has_access(request.user, issue):
        ctx = _base_ctx(request, journal)
        ctx["submission"] = submission
        return render(request, "web/subscription_required.html", ctx, status=403)
    from apps.stats.models import Metric
    from apps.stats.services import StatsService
    StatsService.record(request, submission, Metric.GALLEY_VIEW, galley=g)
    ctx = _base_ctx(request, journal)
    src = g.remote_url or reverse("web:galley", args=[submission.pk, g.pk])
    t = g.publication.tr(ctx["cloc"])
    ctx.update({"submission": submission, "pub": g.publication, "g": g,
                "src": src, "gtitle": (t.title if t else "")})
    return render(request, "web/galley_view.html", ctx)
