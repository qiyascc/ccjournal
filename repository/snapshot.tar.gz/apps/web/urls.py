# ==========================================================
#
# █▀█ █ █▄█ ▄▀█ █▀  █▀▀ █▀▀
# ▀▀█ █ ░█░ █▀█ ▄█  █▄▄ █▄▄
#
# Project     : CC Journal
# Developed by: Qiyas CC
# Copyright © 2026 Qiyas CC
# All Rights Reserved.
# ==========================================================

from django.urls import path

from . import citations, views

app_name = "web"

urlpatterns = [
    path("setup/", views.setup, name="setup"),
    path("page/<slug:slug>/", views.page, name="page"),
    path("", views.home, name="home"),
    path("issues/", views.issue_archive, name="archive"),
    path("issue/<int:pk>/", views.issue_detail, name="issue"),
    path("article/<int:pk>/", views.article, name="article"),
    path("article/<int:pk>/cite.bib", citations.cite_bibtex, name="cite_bibtex"),
    path("article/<int:pk>/cite.ris", citations.cite_ris, name="cite_ris"),
    path("article/<int:pk>/galley/<int:galley_id>/", views.galley, name="galley"),
    path("article/<int:pk>/view/<int:galley_id>/", views.galley_view, name="galley_view"),
    path("section/<int:pk>/", views.section_browse, name="section"),
    path("search/", views.search, name="search"),
    path("announcements/", views.announcements, name="announcements"),
    path("announcement/<int:pk>/", views.announcement_detail, name="announcement"),
    path("categories/", views.categories, name="categories"),
    path("category/<slug:slug>/", views.category_browse, name="category"),
]
