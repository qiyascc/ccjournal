# ==========================================================
#
# █▀█ █ █▄█ ▄▀█ █▀  █▀▀ █▀▀
# ▀▀█ █ ░█░ █▀█ ▄█  █▄▄ █▄▄
#
# Project     : CC Journal
# Developed by: Qiyas CC
# Copyright © 2026 Qiyas CC
# All Rights Reserved.
# ==========================================================

"""OAI-PMH endpoint + Crossref deposit dışa aktarım view'ları."""
from __future__ import annotations

from lxml import etree

from django.http import HttpResponse, HttpResponseBadRequest

from apps.publications.models import Publication, PublicationStatus
from .oai import OAIProvider
from .serializers import to_crossref_deposit


def _xml_response(element, *, status=200) -> HttpResponse:
    body = etree.tostring(element, xml_declaration=True, encoding="UTF-8", pretty_print=True)
    return HttpResponse(body, content_type="text/xml; charset=utf-8", status=status)


def oai(request) -> HttpResponse:
    """OAI-PMH 2.0 endpoint. GET ve POST (spec gereği ikisi de) desteklenir."""
    params = request.POST.dict() if request.method == "POST" else request.GET.dict()
    base_url = request.build_absolute_uri(request.path)
    provider = OAIProvider(base_url)
    return _xml_response(provider.handle(params))


def crossref_deposit(request) -> HttpResponse:
    """
    Seçili yayınlar için Crossref doi_batch üretir (DOI tescili).
    ?issue=<id>  veya  ?publication=<id>  ile filtrelenir; yoksa tüm yayımlananlar.
    """
    qs = Publication.objects.filter(status=PublicationStatus.PUBLISHED).select_related("submission")
    issue_id = request.GET.get("issue")
    pub_id = request.GET.get("publication")
    if issue_id:
        qs = qs.filter(issue_id=issue_id)
    if pub_id:
        qs = qs.filter(id=pub_id)
    pubs = list(qs)
    if not pubs:
        return HttpResponseBadRequest("No published publications match the filter.")
    el = to_crossref_deposit(pubs)
    resp = _xml_response(el)
    resp["Content-Disposition"] = 'attachment; filename="crossref-deposit.xml"'
    return resp
